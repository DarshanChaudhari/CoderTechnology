newFunction();
function newFunction() {
    var fname = "rashmi";
    console.log("Hello Wrold  " + fname);
}
//console.log(fname);
