newFunction();
function newFunction() {
    let fname: String = "rashmi";
    console.log("Hello Wrold  " + fname);
}

console.log(fname);